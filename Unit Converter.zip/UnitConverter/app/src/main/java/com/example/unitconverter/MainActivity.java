package com.example.unitconverter;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private Spinner inputUnit;
    private Spinner outputUnit;
    private Button convertButton;
    private TextView resultText;

    private static final double METER_TO_FEET = 3.28084;
    private static final double METER_TO_INCHES = 39.3701;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.inputValue);
        inputUnit = findViewById(R.id.inputUnit);
        outputUnit = findViewById(R.id.outputUnit);
        convertButton = findViewById(R.id.convertButton);
        resultText = findViewById(R.id.resultText);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.units_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        inputUnit.setAdapter(adapter);
        outputUnit.setAdapter(adapter);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });
    }

    private void convert() {
        double inputValue = Double.parseDouble(this.inputValue.getText().toString());
        String inputUnit = this.inputUnit.getSelectedItem().toString();
        String outputUnit = this.outputUnit.getSelectedItem().toString();

        double result;

        if (inputUnit.equals(outputUnit)) {
            result = inputValue;
        } else if (inputUnit.equals("Meter") && outputUnit.equals("Feet")) {
            result = inputValue * METER_TO_FEET;
        } else if (inputUnit.equals("Meter") && outputUnit.equals("Inches")) {
            result = inputValue * METER_TO_INCHES;
        } else if (inputUnit.equals("Feet") && outputUnit.equals("Meter")) {
            result = inputValue / METER_TO_FEET;
        } else if (inputUnit.equals("Feet") && outputUnit.equals("Inches")) {
            result = inputValue * 12;
        } else if (inputUnit.equals("Inches") && outputUnit.equals("Meter")) {
            result = inputValue / METER_TO_INCHES;
        } else if (inputUnit.equals("Inches") && outputUnit.equals("Feet")) {
            result = inputValue / 12;
        } else {
            result = inputValue;
        }

        resultText.setText(String.valueOf(result));
    }

}

